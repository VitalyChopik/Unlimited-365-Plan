<?php
/*
Template Name: Unlimited 365 plan
Template Post Type: Page
*/
get_header();
the_content();
get_footer();
?>

